﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace calculadora
{
    public partial class Form1 : Form
    {
        Image f1i = new Bitmap(Properties.Resources.f1t);
        Image f2i = new Bitmap(Properties.Resources.f2t);
        Image f3i = new Bitmap(Properties.Resources.f3t);
        Image f4i = new Bitmap(Properties.Resources.f4t);
        Image fri = new Bitmap(Properties.Resources.frt);

        double fxy, fy, fx, fr, frang;

        public Form1()
        {
            //transforma as pictureBox do primeiro mostrador em uma só

            InitializeComponent();
            setaVermelha1.Image = f1i;
            setaVerde2.Image = f2i;
            setaAzul3.Image = f3i;
            setaAmarela4.Image = f4i;
            setaForcaResultante.Image = fri;
            fundoForcas.Image = Properties.Resources.bg;
            fundoForcaResutante.Image = Properties.Resources.bg;
            picBolinha1.Image = Properties.Resources.centro;
            picBolinha2.Image = Properties.Resources.centro;

            setaAmarela4.Controls.Add(picBolinha1);
            picBolinha1.Location = new Point(0, 0);
            picBolinha1.BackColor = Color.Transparent;

            setaAzul3.Controls.Add(setaAmarela4);
            setaAmarela4.Location = new Point(0, 0);
            setaAmarela4.BackColor = Color.Transparent;

            setaVerde2.Controls.Add(setaAzul3);
            setaAzul3.Location = new Point(0, 0);
            setaAzul3.BackColor = Color.Transparent;

            setaVermelha1.Controls.Add(setaVerde2);
            setaVerde2.Location = new Point(0, 0);
            setaVerde2.BackColor = Color.Transparent;

            fundoForcas.Controls.Add(setaVermelha1);
            setaVermelha1.Location = new Point(0, 0);
            setaVermelha1.BackColor = Color.Transparent;

            setaForcaResultante.Parent = fundoForcaResutante;

            //transforma as pictureBox do segundo mostrador em uma só

            setaForcaResultante.Controls.Add(picBolinha2);
            picBolinha2.Location = new Point(0, 0);
            picBolinha2.BackColor = Color.Transparent;

            fundoForcaResutante.Controls.Add(setaForcaResultante);
            setaForcaResultante.Location = new Point(0, 0);
            setaForcaResultante.BackColor = Color.Transparent;


        }
        //METODO QUE GIRA AS IMAGENS
        public static Image RotateImage(Image img, float rotationAngle)
        {
            //create an empty Bitmap image
            Bitmap bmp = new Bitmap(img.Width, img.Height);

            //turn the Bitmap into a Graphics object
            Graphics gfx = Graphics.FromImage(bmp);

            //now we set the rotation point to the center of our image
            gfx.TranslateTransform((float)bmp.Width / 2, (float)bmp.Height / 2);

            //now rotate the image
            gfx.RotateTransform(rotationAngle);

            gfx.TranslateTransform(-(float)bmp.Width / 2, -(float)bmp.Height / 2);

            //set the InterpolationMode to HighQualityBicubic so to ensure a high
            //quality image once it is transformed to the specified size
            gfx.InterpolationMode = InterpolationMode.HighQualityBicubic;

            //now draw our new image onto the graphics object
            gfx.DrawImage(img, new Point(0, 0));

            //dispose of our Graphics object
            gfx.Dispose();

            //return the image
            return bmp;
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double[] cos = new double[5];
            double[] sen = new double[5];

            double[] forc = new double[5];
            float[] ang = new float[4];
            float[] sub = new float[4];
            TextBox[] txtv = new TextBox[4];
            TextBox[] txtf = new TextBox[4];
            txtv[0] = txta1; txtv[1] = txta2; txtv[2] = txta3; txtv[3] = txta4;
            txtf[0] = txtf1; txtf[1] = txtf2; txtf[2] = txtf3; txtf[3] = txtf4;

            //GUARDAR OS ANGULOS
            for (int i = 0; i < 4; i++)
            {
                if (txtv[i].Text != "")
                {
                    ang[i] = float.Parse(txtv[i].Text);
                    if (ang[i] % 360 > 1)
                        ang[i] = ang[i] % 360;
                }
            }

            //GUARDAR AS FORÇAS
            for (int i = 0; i < 4; i++)
            {
                if (txtf[i].Text != "")
                {
                    forc[i] = float.Parse(txtf[i].Text);
                }
            }

            //CALCULAR O OMEGA DOS ANGULOS E SEPARÁ-LOS POR QUADRANTE
            for (int i = 0; i < 4; i++)
            {
                if (ang[i] <= 90)
                    sub[i] = ang[i];
                else if (ang[i] < 180)
                    sub[i] = 180 - ang[i];
                else if (ang[i] < 270)
                    sub[i] = ang[i] - 180;
                else
                    sub[i] = 360 - ang[i];
            }

            //CALCULAR O COSSENO E SENO DOS ANGULOS
            for (int i = 0; i < 4; i++)
            {
                cos[i] = Math.Cos(sub[i] * Math.PI / 180);
                sen[i] = Math.Sin(sub[i] * Math.PI / 180);
            }

            //CALCULAR A FORÇA X E Y
            int[] i1 = new int[] { 4, 4, 4, 4 }, i2 = new int[] { 4, 4, 4, 4 }, i3 = new int[] { 4, 4, 4, 4 }, i4 = new int[] { 4, 4, 4, 4 };
            for (int i = 0; i < 4; i++)
            {
                if (ang[i] < 90)
                    i1[i] = i;
                else if (ang[i] < 180)
                    i2[i] = i;
                else if (ang[i] < 270)
                    i3[i] = i;
                else
                    i4[i] = i;
            }
            
            fx = (forc[i1[0]] * cos[i1[0]] + forc[i1[1]] * cos[i1[1]] + forc[i1[2]] * cos[i1[2]] + forc[i1[3]] * cos[i1[3]]
                + forc[i4[0]] * cos[i4[0]] + forc[i4[1]] * cos[i4[1]] + forc[i4[2]] * cos[i4[2]] + forc[i4[3]] * cos[i4[3]])
                -(forc[i2[0]] * cos[i2[0]] + forc[i2[1]] * cos[i2[1]] + forc[i2[2]] * cos[i2[2]] + forc[i2[3]] * cos[i2[3]]
                + forc[i3[0]] * cos[i3[0]] + forc[i3[1]] * cos[i3[1]] + forc[i3[2]] * cos[i3[2]] + forc[i3[3]] * cos[i3[3]]);

            fy = (forc[i1[0]] * sen[i1[0]] + forc[i1[1]] * sen[i1[1]] + forc[i1[2]] * sen[i1[2]] + forc[i1[3]] * sen[i1[3]]
                + forc[i2[0]] * sen[i2[0]] + forc[i2[1]] * sen[i2[1]] + forc[i2[2]] * sen[i2[2]] + forc[i2[3]] * sen[i2[3]])
                -(forc[i4[0]] * sen[i4[0]] + forc[i4[1]] * sen[i4[1]] + forc[i4[2]] * sen[i4[2]] + forc[i4[3]] * sen[i4[3]]
                + forc[i3[0]] * sen[i3[0]] + forc[i3[1]] * sen[i3[1]] + forc[i3[2]] * sen[i3[2]] + forc[i3[3]] * sen[i3[3]]);

            fr = Math.Sqrt(fx * fx + fy * fy);

            if (fx != 0 && fy != 0)
                frang = (180 / Math.PI) * (Math.Atan(fy / fx));

            //GIRAR AS SETAS
            setaForcaResultante.Image = RotateImage(fri, -float.Parse(Convert.ToString(frang)));
            label1.Text = Convert.ToString(frang);
            label2.Text = Convert.ToString(fx);
            label3.Text = Convert.ToString(fy);


            if (txta1.Text != "")
                setaVermelha1.Image = RotateImage(f1i, -float.Parse(txta1.Text));
            if (txta2.Text != "")
                setaVerde2.Image = RotateImage(f2i, -float.Parse(txta2.Text));
            if (txta3.Text != "")
                setaAzul3.Image = RotateImage(f3i, -float.Parse(txta3.Text));
            if (txta4.Text != "")
                setaAmarela4.Image = RotateImage(f4i, -float.Parse(txta4.Text));


            //RETIRA A SETA DA FORCA RESULTANTE CASO ELA SEJA NULA
            if (fr == 0)
                setaForcaResultante.Image = null;
        }
    }
}
