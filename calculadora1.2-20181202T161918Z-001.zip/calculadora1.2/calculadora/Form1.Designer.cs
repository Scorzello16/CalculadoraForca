﻿namespace calculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.setaVermelha1 = new System.Windows.Forms.PictureBox();
            this.txtf1 = new System.Windows.Forms.TextBox();
            this.txtf2 = new System.Windows.Forms.TextBox();
            this.txtf3 = new System.Windows.Forms.TextBox();
            this.txtf4 = new System.Windows.Forms.TextBox();
            this.txta1 = new System.Windows.Forms.TextBox();
            this.txta2 = new System.Windows.Forms.TextBox();
            this.txta3 = new System.Windows.Forms.TextBox();
            this.txta4 = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.setaVerde2 = new System.Windows.Forms.PictureBox();
            this.setaAzul3 = new System.Windows.Forms.PictureBox();
            this.setaAmarela4 = new System.Windows.Forms.PictureBox();
            this.fundoForcas = new System.Windows.Forms.PictureBox();
            this.fundoForcaResutante = new System.Windows.Forms.PictureBox();
            this.setaForcaResultante = new System.Windows.Forms.PictureBox();
            this.picBolinha1 = new System.Windows.Forms.PictureBox();
            this.picBolinha2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.setaVermelha1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.setaVerde2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.setaAzul3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.setaAmarela4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fundoForcas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fundoForcaResutante)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.setaForcaResultante)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBolinha1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBolinha2)).BeginInit();
            this.SuspendLayout();
            // 
            // setaVermelha1
            // 
            this.setaVermelha1.BackColor = System.Drawing.Color.Transparent;
            this.setaVermelha1.Location = new System.Drawing.Point(299, 19);
            this.setaVermelha1.Name = "setaVermelha1";
            this.setaVermelha1.Size = new System.Drawing.Size(300, 300);
            this.setaVermelha1.TabIndex = 9;
            this.setaVermelha1.TabStop = false;
            // 
            // txtf1
            // 
            this.txtf1.Location = new System.Drawing.Point(13, 35);
            this.txtf1.Name = "txtf1";
            this.txtf1.Size = new System.Drawing.Size(100, 20);
            this.txtf1.TabIndex = 0;
            this.txtf1.Text = "10";
            // 
            // txtf2
            // 
            this.txtf2.Location = new System.Drawing.Point(13, 82);
            this.txtf2.Name = "txtf2";
            this.txtf2.Size = new System.Drawing.Size(100, 20);
            this.txtf2.TabIndex = 1;
            this.txtf2.Text = "10";
            // 
            // txtf3
            // 
            this.txtf3.Location = new System.Drawing.Point(13, 135);
            this.txtf3.Name = "txtf3";
            this.txtf3.Size = new System.Drawing.Size(100, 20);
            this.txtf3.TabIndex = 2;
            this.txtf3.Text = "10";
            // 
            // txtf4
            // 
            this.txtf4.Location = new System.Drawing.Point(13, 182);
            this.txtf4.Name = "txtf4";
            this.txtf4.Size = new System.Drawing.Size(100, 20);
            this.txtf4.TabIndex = 3;
            this.txtf4.Text = "10";
            // 
            // txta1
            // 
            this.txta1.Location = new System.Drawing.Point(150, 35);
            this.txta1.Name = "txta1";
            this.txta1.Size = new System.Drawing.Size(100, 20);
            this.txta1.TabIndex = 4;
            this.txta1.Text = "0";
            // 
            // txta2
            // 
            this.txta2.Location = new System.Drawing.Point(150, 82);
            this.txta2.Name = "txta2";
            this.txta2.Size = new System.Drawing.Size(100, 20);
            this.txta2.TabIndex = 5;
            this.txta2.Text = "90";
            // 
            // txta3
            // 
            this.txta3.Location = new System.Drawing.Point(150, 135);
            this.txta3.Name = "txta3";
            this.txta3.Size = new System.Drawing.Size(100, 20);
            this.txta3.TabIndex = 6;
            this.txta3.Text = "180";
            // 
            // txta4
            // 
            this.txta4.Location = new System.Drawing.Point(150, 182);
            this.txta4.Name = "txta4";
            this.txta4.Size = new System.Drawing.Size(100, 20);
            this.txta4.TabIndex = 7;
            this.txta4.Text = "270";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(93, 256);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 8;
            this.btnCalcular.Text = "button1";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // setaVerde2
            // 
            this.setaVerde2.BackColor = System.Drawing.Color.Transparent;
            this.setaVerde2.Location = new System.Drawing.Point(299, 19);
            this.setaVerde2.Name = "setaVerde2";
            this.setaVerde2.Size = new System.Drawing.Size(300, 300);
            this.setaVerde2.TabIndex = 10;
            this.setaVerde2.TabStop = false;
            // 
            // setaAzul3
            // 
            this.setaAzul3.BackColor = System.Drawing.Color.Transparent;
            this.setaAzul3.Location = new System.Drawing.Point(299, 19);
            this.setaAzul3.Name = "setaAzul3";
            this.setaAzul3.Size = new System.Drawing.Size(300, 300);
            this.setaAzul3.TabIndex = 11;
            this.setaAzul3.TabStop = false;
            // 
            // setaAmarela4
            // 
            this.setaAmarela4.BackColor = System.Drawing.Color.Transparent;
            this.setaAmarela4.Location = new System.Drawing.Point(299, 19);
            this.setaAmarela4.Name = "setaAmarela4";
            this.setaAmarela4.Size = new System.Drawing.Size(300, 300);
            this.setaAmarela4.TabIndex = 12;
            this.setaAmarela4.TabStop = false;
            // 
            // fundoForcas
            // 
            this.fundoForcas.BackColor = System.Drawing.Color.Transparent;
            this.fundoForcas.Location = new System.Drawing.Point(299, 19);
            this.fundoForcas.Name = "fundoForcas";
            this.fundoForcas.Size = new System.Drawing.Size(300, 300);
            this.fundoForcas.TabIndex = 13;
            this.fundoForcas.TabStop = false;
            // 
            // fundoForcaResutante
            // 
            this.fundoForcaResutante.BackColor = System.Drawing.Color.Transparent;
            this.fundoForcaResutante.Location = new System.Drawing.Point(638, 19);
            this.fundoForcaResutante.Name = "fundoForcaResutante";
            this.fundoForcaResutante.Size = new System.Drawing.Size(300, 300);
            this.fundoForcaResutante.TabIndex = 14;
            this.fundoForcaResutante.TabStop = false;
            // 
            // setaForcaResultante
            // 
            this.setaForcaResultante.BackColor = System.Drawing.Color.Transparent;
            this.setaForcaResultante.Location = new System.Drawing.Point(638, 19);
            this.setaForcaResultante.Name = "setaForcaResultante";
            this.setaForcaResultante.Size = new System.Drawing.Size(300, 300);
            this.setaForcaResultante.TabIndex = 15;
            this.setaForcaResultante.TabStop = false;
            // 
            // picBolinha1
            // 
            this.picBolinha1.BackColor = System.Drawing.Color.Transparent;
            this.picBolinha1.Location = new System.Drawing.Point(299, 19);
            this.picBolinha1.Name = "picBolinha1";
            this.picBolinha1.Size = new System.Drawing.Size(300, 300);
            this.picBolinha1.TabIndex = 16;
            this.picBolinha1.TabStop = false;
            // 
            // picBolinha2
            // 
            this.picBolinha2.BackColor = System.Drawing.Color.Transparent;
            this.picBolinha2.Location = new System.Drawing.Point(638, 19);
            this.picBolinha2.Name = "picBolinha2";
            this.picBolinha2.Size = new System.Drawing.Size(300, 300);
            this.picBolinha2.TabIndex = 17;
            this.picBolinha2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(987, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(990, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(990, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "label3";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::calculadora.Properties.Resources.fade;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1112, 327);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picBolinha2);
            this.Controls.Add(this.picBolinha1);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txta4);
            this.Controls.Add(this.txta3);
            this.Controls.Add(this.txta2);
            this.Controls.Add(this.txta1);
            this.Controls.Add(this.txtf4);
            this.Controls.Add(this.txtf3);
            this.Controls.Add(this.txtf2);
            this.Controls.Add(this.txtf1);
            this.Controls.Add(this.setaForcaResultante);
            this.Controls.Add(this.fundoForcaResutante);
            this.Controls.Add(this.fundoForcas);
            this.Controls.Add(this.setaAmarela4);
            this.Controls.Add(this.setaAzul3);
            this.Controls.Add(this.setaVerde2);
            this.Controls.Add(this.setaVermelha1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.setaVermelha1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.setaVerde2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.setaAzul3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.setaAmarela4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fundoForcas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fundoForcaResutante)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.setaForcaResultante)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBolinha1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBolinha2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox setaVermelha1;
        private System.Windows.Forms.TextBox txtf1;
        private System.Windows.Forms.TextBox txtf2;
        private System.Windows.Forms.TextBox txtf3;
        private System.Windows.Forms.TextBox txtf4;
        private System.Windows.Forms.TextBox txta1;
        private System.Windows.Forms.TextBox txta2;
        private System.Windows.Forms.TextBox txta3;
        private System.Windows.Forms.TextBox txta4;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.PictureBox setaVerde2;
        private System.Windows.Forms.PictureBox setaAzul3;
        private System.Windows.Forms.PictureBox setaAmarela4;
        private System.Windows.Forms.PictureBox fundoForcas;
        private System.Windows.Forms.PictureBox fundoForcaResutante;
        private System.Windows.Forms.PictureBox setaForcaResultante;
        private System.Windows.Forms.PictureBox picBolinha1;
        private System.Windows.Forms.PictureBox picBolinha2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

